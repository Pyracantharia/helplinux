#!/bin/sh

arg=$1
arg2=$2

result=$((arg + arg2))
echo "$result"
